### 0.1.3
- Allow every printable ASCII char to be used within arguments. #9

### 0.1.2
- Allow `+` to be used within arguments. #8

### 0.1.1
- Fixed a bug where long arguments with `/` file slashes were ignored.

### 0.1.0
- Added support for parsing short arguments (correctly) see bugs #5 & #6 this
  was a sort of breaking change (which explains the bump).

### 0.0.1
- Added support for keys with a dot notation so it's automatically parsed to an
  object.
- Better value parsing
